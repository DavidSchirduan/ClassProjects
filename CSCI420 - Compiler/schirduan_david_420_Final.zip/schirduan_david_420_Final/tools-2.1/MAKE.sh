javac -cp .:/~tools-2.1 Triangle/SyntacticAnalyzer/Token.java
javac -cp .:/~tools-2.1 Triangle/Compiler.java
javac -cp .:/~tools-2.1 TAM/Interpreter.java
javac -cp .:/~tools-2.1 TAM/Disassembler.java
