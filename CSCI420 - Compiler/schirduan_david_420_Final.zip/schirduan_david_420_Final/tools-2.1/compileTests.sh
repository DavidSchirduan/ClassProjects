java -cp ~/tools-2.1 Triangle.Compiler $1
java -cp ~/tools-2.1 TAM.Interpreter obj.tam
java -cp ~/tools-2.1 TAM.Disassembler obj.tam
rm -r ~/tools-2.1/obj.tam
