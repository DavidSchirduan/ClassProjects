#include <assert.h>
#include <stdio.h>
#include "point.h"

/*
 * Update *p by increasing p->x by x and 
 * p->y by y
 */
void point_translate(Point *p, double x, double y)
{
  printf("Your job is to implement translate\n");
  assert(0);
}

/*
 * Return the distance from p1 to p2
 */
double point_distance(const Point *p1, const Point *p2)
{
  printf("Your job is to implement distance\n");
  assert(0);
  return -1.0;
}
