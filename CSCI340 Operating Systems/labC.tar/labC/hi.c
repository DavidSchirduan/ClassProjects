#include <stdio.h>

int
main(int argc, char **argv)
{
  printf("So far %s\n", "so good.");
  return 0;

}
