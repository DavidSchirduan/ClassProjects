<?php
echo '<a href="http://localhost/332Project/index.php">Home</a> <a href="http://localhost/332Project/UserHome.php">Users</a> <a href="http://localhost/332Project/CreatorHome.php">Creators</a> <a href="http://localhost/332Project/QuizHome.php">Quizzes</a> <a href="http://localhost/332Project/QuestionHome.php">Questions</a> <a href="http://localhost/332Project/AnswerHome.php">Answers</a> <a href="http://localhost/332Project/GroupHome.php">Groups</a>'
?>
