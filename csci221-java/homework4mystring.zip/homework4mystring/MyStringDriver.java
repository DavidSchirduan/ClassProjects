
public class MyStringDriver
   {
      static MyString string1 = new MyString("hellosir");
      static MyString string2 = new MyString("ola");
      static MyString stringtest = new MyString("ello");
      
      public static void main(String[] args)
         {
            
//            System.out.println(string1.length());
//            
//            System.out.println(string2.atChar(8));
//
//            System.out.println(string1.equals(string2));
//            
//            System.out.println(string1.clone()); 
//            
//            stringtest = string1.concat(string2);
//            System.out.println(stringtest);
//        
//            System.out.println(string1.indexOf('l', 4));
//           
//            System.out.println(string1.substring(1, 4));
//            
//            
//           System.out.println(string2.indexOf(string1, 5));
            
            System.out.println(string1.replace(stringtest, string2));
            
            
         }

   }
