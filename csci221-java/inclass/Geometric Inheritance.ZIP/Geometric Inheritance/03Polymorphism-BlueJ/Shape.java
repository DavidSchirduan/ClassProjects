/**
 * class Shape
 * 
 * @author Pharr 
 * @version 1/18/07
 */
public class Shape
{
    public double area()
    {
        return 0.0;
    }
}
